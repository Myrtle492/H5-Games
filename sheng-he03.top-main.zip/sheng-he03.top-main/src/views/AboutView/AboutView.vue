<script setup>
import HeaderWidget from '@/components/HeaderWidget.vue'
import FooterWidget from '@/components/FooterWidget.vue'
</script>

<template>
  <div class="px-[10vw] pt-12">
    <div class="mb-4 h-[94px] w-[94px]">
      <HeaderWidget />
    </div>
    <article class="prose container mx-auto bg-white px-[10vw] py-12">
      <h1>About</h1>
      <p>
        A place where the fun never stops, and each experience brings a new kind of thrill that
        you’ve never experienced. Our target is to have only the best quality free online games. You
        don’t need to pay or even download anything. We are an online gaming experience dedicated to
        bringing you the best games online at absolutely zero cost. Whatever kind of online game
        you’re looking for, we’ve got multiple selections to suit each play style – and when we say
        “multiple,” we mean “hundreds upon hundreds” of games! This is all that we do, and if we may
        say so, we’re very good at it. We know how gamers think because we aregamers. This place was
        built just for you.
      </p>
    </article>
  </div>
  <FooterWidget />
</template>
