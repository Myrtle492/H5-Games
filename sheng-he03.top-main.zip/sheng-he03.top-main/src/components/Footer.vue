<template>
    <div class="footer">
        <div class="content">
            <LinkWidget href="/about">About</LinkWidget> ·
            <LinkWidget href="/privacy">Privacy</LinkWidget>
        </div>
    </div>
</template>

<style lang="scss" scoped>
    .footer {
        width: 100%;
        height: 50px;
        color: #fff;
        font-size: 13px;
        background: #25b3e5;
        padding: 0 20px;
        .content {
            text-align: center;
            line-height: 50px;
        }
    }
</style>
